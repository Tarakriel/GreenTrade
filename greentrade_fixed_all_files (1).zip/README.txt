GreenTrade C2C E-Commerce Platform

Project Description:
GreenTrade is a Customer-to-Customer e-commerce platform based on the Deliverable 1 proposal.
It allows individual users to buy and sell goods safely within local communities.

The system includes:
- User registration and login
- Product listings
- Product search
- Messaging between buyer and seller
- Escrow-style payment workflow
- Delivery or pickup options
- Order tracking
- Dispute reporting
- Admin dashboard
- Role-Based Access Control (RBAC)

Technologies Used:
- PHP
- MySQL
- Bootstrap
- HTML
- CSS
- JavaScript


Folder Structure:
- admin/        Admin website pages
- assets/       CSS and JavaScript files
- database/     MySQL database script
- includes/     Reusable PHP files
- uploads/      Uploaded product images

Setup Instructions:
1. Install and open XAMPP.
2. Start Apache and MySQL.
3. Copy the greentrade folder into C:/xampp/htdocs/.
4. Open phpMyAdmin.
5. Create a database called greentrade.
6. Import database/greentrade.sql.
7. Open the website using:
   http://localhost/greentrade

Admin Setup:
1. Register a normal user on register.php.
2. Go to phpMyAdmin.
3. Open the users table.
4. Change that user's role_id to 3 for admin access.
5. Login again and open:
   http://localhost/greentrade/admin/dashboard.php

Important Submission Note:
For Deliverable 3, the website must be hosted online.
Localhost submissions are not accepted for the final presentation.
