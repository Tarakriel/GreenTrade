<?php
include "includes/db.php";
include "includes/header.php";

if (!isset($_SESSION['user_id'])) {
    header("Location: login.php");
    exit();
}

$user_id = (int)$_SESSION['user_id'];

$sql = "SELECT orders.*, listings.title, listings.price
        FROM orders
        INNER JOIN listings ON orders.listing_id = listings.listing_id
        WHERE orders.buyer_id = ? OR orders.seller_id = ?
        ORDER BY orders.created_at DESC";

$stmt = $conn->prepare($sql);
$stmt->bind_param("ii", $user_id, $user_id);
$stmt->execute();
$orders = $stmt->get_result();
?>

<h2>Order Tracking</h2>
<p>Track the progress of your GreenTrade orders.</p>

<?php if ($orders->num_rows > 0): ?>
    <?php while ($order = $orders->fetch_assoc()): ?>
        <div class="card mb-3 shadow-sm">
            <div class="card-body">
                <h5>Order #<?php echo (int)$order['order_id']; ?></h5>
                <p><strong>Product:</strong> <?php echo htmlspecialchars($order['title']); ?></p>
                <p><strong>Amount:</strong> R <?php echo number_format((float)$order['price'], 2); ?></p>
                <p><strong>Delivery Method:</strong> <?php echo htmlspecialchars($order['delivery_method']); ?></p>
                <p><strong>Status:</strong>
                    <span class="badge bg-success"><?php echo htmlspecialchars($order['order_status']); ?></span>
                </p>

                <div class="d-flex flex-wrap gap-2 my-3">
                    <span class="badge bg-primary p-2">Order Created</span>
                    <span class="badge <?php echo in_array($order['order_status'], ['paid','delivered','completed','disputed']) ? 'bg-primary' : 'bg-secondary'; ?> p-2">Payment Held</span>
                    <span class="badge <?php echo in_array($order['order_status'], ['delivered','completed']) ? 'bg-primary' : 'bg-secondary'; ?> p-2">Delivered</span>
                    <span class="badge <?php echo $order['order_status'] === 'completed' ? 'bg-primary' : 'bg-secondary'; ?> p-2">Completed</span>
                </div>

                <a href="dispute_report.php?order_id=<?php echo (int)$order['order_id']; ?>" class="btn btn-warning btn-sm">Report Dispute</a>
            </div>
        </div>
    <?php endwhile; ?>
<?php else: ?>
    <div class="alert alert-info">You do not have any orders to track yet.</div>
    <a href="listing.php" class="btn btn-success">Browse Listings</a>
<?php endif; ?>

<?php include "includes/footer.php"; ?>
