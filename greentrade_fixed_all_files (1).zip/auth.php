<?php
if (session_status() === PHP_SESSION_NONE) {
    session_start();
}

function isLoggedIn() {
    return isset($_SESSION['user_id']);
}

function requireLogin() {
    if (!isLoggedIn()) {
        header("Location: login.php");
        exit();
    }
}

function requireAdmin() {
    if (!isLoggedIn()) {
        header("Location: ../login.php");
        exit();
    }

    if (!isset($_SESSION['role_id']) || !in_array((int)$_SESSION['role_id'], [3, 4], true)) {
        header("Location: ../index.php");
        exit();
    }
}

function requireSeller() {
    if (!isLoggedIn()) {
        header("Location: ../login.php");
        exit();
    }

    if (!isset($_SESSION['role_id']) || !in_array((int)$_SESSION['role_id'], [2, 3, 4], true)) {
        header("Location: ../index.php");
        exit();
    }
}
?>
