<?php
if (session_status() === PHP_SESSION_NONE) {
    session_start();
}
?>
<!DOCTYPE html>
<html>
    <head>
        <title>GreenTrade</title>
        <meta name="viewport" content="width=device-width, initial-scale=1">

        <link
        href="https://cdn.jsdelivr.net/npm/bootstrap@5.3.0/dist/css/bootstrap.min.css"
        rel="stylesheet">

        <link rel="stylesheet" href="assets/css/style.css">
</head>
<body>

<nav class="navbar navbar-expand-lg navbar-dark bg-success">
    <div class="container">
        <a class="navbar-brand" href="index.php">GreenTrade</a>

        <div>
            <a href="index.php" class="btn btn-light btn-sm">Home</a>
            <?php if (isset($_SESSION['user_id'])): ?>
                <a href="create_listing.php" class="btn btn-light btn-sm">SELL Item</a>
                <a href="orders.php" class="btn btn-light btn-sm">Orders</a>
                <a href="messages.php" class="btn btn-light btn-sm">Messages</a>

                <?php if($_SESSION['role_id'] == 3 || $_SESSION['role_id'] == 4): ?>
                    <a href="admin/dashboard.php" class="btn btn-warning btn-sm">Admin</a>
                <?php endif; ?>

                <a href="logout.php" class="btn btn-danger btn-sm">Logout</a>
            <?php else: ?>
                <a href="login.php" class="btn btn-light btn-sm">Login</a>
                <a href="register.php" class="btn btn-light btn-sm">Register</a>
            <?php endif; ?>
        </div>
    </div>
</nav>
<div class="container mt-4">
