<?php
include "includes/db.php";
include "includes/auth.php";
requireLogin();
include "includes/header.php";

$order_id = $_GET['order'];
$user_id = $_SESSION['user_id'];

if (isset($_POST['submit_dispute'])) {
    $reason = $conn->real_escape_string($_POST['reason']);
    $description = $conn->real_escape_string($_POST['description']);

    $sql = "INSERT INTO disputes (order_id, user_id, reason, description)
    VALUES ('$order_id', '$user_id', '$reason', '$description')";
    if ($conn->query($sql)) {
        $conn->query("UPDATE orders SET order_status='disputed' WHERE order_id='$order_id'");
        echo "<div class='alert alert-success'>Dispute submitted successfully.</div>";
    } else {
        echo "<div class='alert alert-danger'>Error submitting dispute.</div>";
    }
}
?>
<h2>Open Dispute</h2>
<form method="POST">
    <input type="text" name="reason" class="form-control mb-2" placeholder="Reason" required>
    <textarea name="description" class="form-control mb-2" placeholder="Describe the issue" required></textarea>
    <button name="submit_dispute" class="btn btn-danger">Submit Dispute</button>
</form>
<?php include "includes/footer.php"; ?>
