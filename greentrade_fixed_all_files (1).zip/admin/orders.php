<?php
error_reporting(E_ALL);
ini_set('display_errors', 1);
session_start();

require_once __DIR__ . "/../includes/db.php";
$message = "";

/* Update order status */
if ($_SERVER["REQUEST_METHOD"] === "POST" && isset($_POST['update_status'])) {
    $order_id = (int)$_POST['order_id'];
    $order_status = $_POST['order_status'];

    $allowed_statuses = ['pending', 'paid', 'delivered', 'completed', 'cancelled', 'disputed'];

    if (!in_array($order_status, $allowed_statuses)) {
        $message = "<div class='alert error'>Invalid order status selected.</div>";
    } else {
        $stmt = $conn->prepare("UPDATE orders SET order_status = ? WHERE order_id = ?");

        if (!$stmt) {
            die("Update prepare failed: " . $conn->error);
        }

        $stmt->bind_param("si", $order_status, $order_id);

        if ($stmt->execute()) {
            $message = "<div class='alert success'>Order status updated successfully.</div>";
        } else {
            $message = "<div class='alert error'>Update failed: " . $stmt->error . "</div>";
        }

        $stmt->close();
    }
}

/* Delete order */
if (isset($_GET['delete'])) {
    $order_id = (int)$_GET['delete'];

    $stmt = $conn->prepare("DELETE FROM orders WHERE order_id = ?");

    if (!$stmt) {
        die("Delete prepare failed: " . $conn->error);
    }

    $stmt->bind_param("i", $order_id);

    if ($stmt->execute()) {
        $message = "<div class='alert success'>Order deleted successfully.</div>";
    } else {
        $message = "<div class='alert error'>Delete failed: " . $stmt->error . "</div>";
    }

    $stmt->close();
}

/* Get orders */
$sql = "SELECT orders.*, 
               buyer.full_name AS buyer_name,
               buyer.email AS buyer_email,
               seller.full_name AS seller_name,
               seller.email AS seller_email,
               listings.title AS listing_title,
               listings.price,
               payments.payment_method,
               payments.escrow_status,
               payments.paid_at
        FROM orders
        LEFT JOIN users AS buyer ON orders.buyer_id = buyer.user_id
        LEFT JOIN users AS seller ON orders.seller_id = seller.user_id
        LEFT JOIN listings ON orders.listing_id = listings.listing_id
        LEFT JOIN payments ON orders.order_id = payments.order_id
        ORDER BY orders.created_at DESC";

$orders = $conn->query($sql);

if (!$orders) {
    die("Orders query failed: " . $conn->error);
}
?>

<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <title>Order Management - GreenTrade Admin</title>
    <meta name="viewport" content="width=device-width, initial-scale=1.0">

    <style>
        * {
            box-sizing: border-box;
        }

        body {
            margin: 0;
            font-family: Arial, sans-serif;
            background: #f4f8f4;
            color: #222;
        }

        .navbar {
            background: #198754;
            color: white;
            padding: 18px 40px;
            display: flex;
            justify-content: space-between;
            align-items: center;
        }

        .navbar h2 {
            margin: 0;
        }

        .navbar a {
            color: white;
            text-decoration: none;
            margin-left: 18px;
            font-weight: bold;
        }

        .container {
            padding: 35px 40px;
        }

        h1 {
            color: #198754;
            margin-top: 0;
        }

        .table-wrap {
            background: white;
            padding: 20px;
            border-radius: 14px;
            box-shadow: 0 4px 14px rgba(0,0,0,0.08);
            overflow-x: auto;
        }

        table {
            width: 100%;
            border-collapse: collapse;
            min-width: 1200px;
        }

        th, td {
            padding: 13px;
            border-bottom: 1px solid #ddd;
            text-align: left;
            vertical-align: top;
        }

        th {
            background: #e8f5e9;
            color: #198754;
        }

        select {
            padding: 8px;
            border-radius: 6px;
            border: 1px solid #ccc;
        }

        button {
            background: #198754;
            color: white;
            border: none;
            padding: 8px 11px;
            border-radius: 6px;
            font-weight: bold;
            cursor: pointer;
        }

        button:hover {
            background: #146c43;
        }

        .delete {
            background: #dc3545;
            color: white;
            padding: 8px 11px;
            border-radius: 6px;
            text-decoration: none;
            font-weight: bold;
            display: inline-block;
        }

        .delete:hover {
            background: #bb2d3b;
        }

        .badge {
            padding: 6px 11px;
            border-radius: 20px;
            font-size: 13px;
            display: inline-block;
            font-weight: bold;
        }

        .pending {
            background: #fff3cd;
            color: #664d03;
        }

        .paid {
            background: #cff4fc;
            color: #055160;
        }

        .delivered {
            background: #d1e7dd;
            color: #0f5132;
        }

        .completed {
            background: #198754;
            color: white;
        }

        .cancelled {
            background: #e2e3e5;
            color: #41464b;
        }

        .disputed {
            background: #f8d7da;
            color: #842029;
        }

        .alert {
            padding: 12px;
            border-radius: 8px;
            margin-bottom: 18px;
            text-align: center;
            font-weight: bold;
        }

        .success {
            background: #d1e7dd;
            color: #0f5132;
        }

        .error {
            background: #f8d7da;
            color: #842029;
        }

        @media(max-width: 700px) {
            .navbar {
                flex-direction: column;
                text-align: center;
                gap: 10px;
                padding: 15px;
            }

            .navbar a {
                display: inline-block;
                margin: 5px;
            }

            .container {
                padding: 25px 15px;
            }
        }
    </style>
</head>

<body>

<div class="navbar">
    <h2>GreenTrade Admin</h2>

    <div>
        <a href="dashboard.php">Dashboard</a>
        <a href="users.php">Users</a>
        <a href="roles.php">Roles</a>
        <a href="listing.php">Listings</a>
        <a href="disputes.php">Disputes</a>
        <a href="../listing.php">Main Site</a>
    </div>
</div>

<div class="container">
    <h1>Order Management</h1>

    <?php echo $message; ?>

    <div class="table-wrap">
        <table>
            <tr>
                <th>Order ID</th>
                <th>Listing</th>
                <th>Buyer</th>
                <th>Seller</th>
                <th>Amount</th>
                <th>Delivery</th>
                <th>Payment</th>
                <th>Escrow</th>
                <th>Status</th>
                <th>Created</th>
                <th>Update Status</th>
                <th>Delete</th>
            </tr>

            <?php if ($orders->num_rows > 0): ?>
                <?php while ($row = $orders->fetch_assoc()): ?>
                    <tr>
                        <td>#<?php echo (int)$row['order_id']; ?></td>

                        <td>
                            <?php echo htmlspecialchars($row['listing_title'] ?? 'No listing found'); ?><br>
                            <small>Listing ID: <?php echo (int)$row['listing_id']; ?></small>
                        </td>

                        <td>
                            <?php echo htmlspecialchars($row['buyer_name'] ?? 'Unknown Buyer'); ?><br>
                            <small><?php echo htmlspecialchars($row['buyer_email'] ?? ''); ?></small>
                        </td>

                        <td>
                            <?php echo htmlspecialchars($row['seller_name'] ?? 'Unknown Seller'); ?><br>
                            <small><?php echo htmlspecialchars($row['seller_email'] ?? ''); ?></small>
                        </td>

                        <td>R <?php echo number_format((float)($row['price'] ?? 0), 2); ?></td>

                        <td><?php echo htmlspecialchars($row['delivery_method'] ?? ''); ?></td>

                        <td>
                            <?php echo htmlspecialchars($row['payment_method'] ?? 'No payment record'); ?><br>
                            <small><?php echo htmlspecialchars($row['paid_at'] ?? ''); ?></small>
                        </td>

                        <td><?php echo htmlspecialchars($row['escrow_status'] ?? 'N/A'); ?></td>

                        <td>
                            <span class="badge <?php echo htmlspecialchars($row['order_status']); ?>">
                                <?php echo htmlspecialchars($row['order_status']); ?>
                            </span>
                        </td>

                        <td><?php echo htmlspecialchars($row['created_at']); ?></td>

                        <td>
                            <form method="POST">
                                <input type="hidden" name="order_id" value="<?php echo (int)$row['order_id']; ?>">

                                <select name="order_status">
                                    <option value="pending" <?php echo ($row['order_status'] === 'pending') ? 'selected' : ''; ?>>Pending</option>
                                    <option value="paid" <?php echo ($row['order_status'] === 'paid') ? 'selected' : ''; ?>>Paid</option>
                                    <option value="delivered" <?php echo ($row['order_status'] === 'delivered') ? 'selected' : ''; ?>>Delivered</option>
                                    <option value="completed" <?php echo ($row['order_status'] === 'completed') ? 'selected' : ''; ?>>Completed</option>
                                    <option value="cancelled" <?php echo ($row['order_status'] === 'cancelled') ? 'selected' : ''; ?>>Cancelled</option>
                                    <option value="disputed" <?php echo ($row['order_status'] === 'disputed') ? 'selected' : ''; ?>>Disputed</option>
                                </select>

                                <button type="submit" name="update_status">Update</button>
                            </form>
                        </td>

                        <td>
                            <a class="delete"
                               href="orders.php?delete=<?php echo (int)$row['order_id']; ?>"
                               onclick="return confirm('Are you sure you want to delete this order?');">
                                Delete
                            </a>
                        </td>
                    </tr>
                <?php endwhile; ?>
            <?php else: ?>
                <tr>
                    <td colspan="12">No orders found.</td>
                </tr>
            <?php endif; ?>
        </table>
    </div>
</div>

</body>
</html>