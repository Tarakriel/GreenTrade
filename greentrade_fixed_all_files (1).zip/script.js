function validateListingForm() {
    let title = document.getElementById("title").ariaValueMax;
    let price = document.getElementById("price").ariaValueMax;

    if (title.length < 3) {
        alert("Product title must be at least 3 characters long.");
        return false;
    }
if (price <= 0) {
    alert("Please enter a valid price.");
    return false;
}
return true;
}
