<?php
include "includes/db.php";
include "includes/header.php";

if (isset($_POST['reset'])) {
    $email = $conn->real_escape_string($_POST['email']);
    $new_password = $_POST['password'];
    $confirm = $_POST['confirm_password'];

    if ($new_password !== $confirm) {
        echo "<div class='alert alert-danger'>Passwords do not match.</div>";
    } else {
        $check = $conn->query("SELECT user_id FROM users WHERE email='$email'");
        if ($check->num_rows == 1) {
            $hashed = password_hash($new_password, PASSWORD_DEFAULT);
            $conn->query("UPDATE users SET password='$hashed' WHERE email='$email'");
            echo "<div class='alert alert-success'>Password reset successfully. <a href='login.php'>You can now login.</a></div>";
        } else {
            echo "<div class='alert alert-danger'>No account found with that email.</div>";
        }
    }
}
?>
<h2>Reset Password</h2>
<form method="POST">
    <input type="email" name="email" class="form-control mb-2" placeholder="Your Email" required>
    <input type="password" name="password" class="form-control mb-2" placeholder="New Password" required>
    <input type="password" name="confirm_password" class="form-control mb-2" placeholder="Confirm New Password" required>
    <button name="reset" class="btn btn-success">Reset Password</button>
</form>
<?php include "includes/footer.php"; ?>
