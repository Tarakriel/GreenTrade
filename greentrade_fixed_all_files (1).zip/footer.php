</div>

<footer class="bg-dark text-white text-center p-3 mt-5">
    <p>&copy; 2026 GreenTrade C2C Marketplace</p>
</footer>

<script src="assets/js/script.js"></script>
</body>
</html>
