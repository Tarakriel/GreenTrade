<?php
include "includes/db.php";
include "includes/header.php";

if (!isset($_SESSION['user_id'])) {
    header("Location: login.php");
    exit();
}

$user_id = (int)$_SESSION['user_id'];
$selected_order_id = isset($_GET['order_id']) ? (int)$_GET['order_id'] : 0;
$message = "";
$error = "";

if ($_SERVER["REQUEST_METHOD"] === "POST") {
    $order_id = (int)($_POST['order_id'] ?? 0);
    $reason = trim($_POST['reason'] ?? "");
    $description = trim($_POST['description'] ?? "");

    if ($order_id <= 0 || $reason === "" || $description === "") {
        $error = "Please complete all fields.";
    } else {
        $check = $conn->prepare("SELECT order_id FROM orders WHERE order_id = ? AND (buyer_id = ? OR seller_id = ?)");
        $check->bind_param("iii", $order_id, $user_id, $user_id);
        $check->execute();
        $allowed = $check->get_result();

        if ($allowed->num_rows === 0) {
            $error = "You can only report disputes for your own orders.";
        } else {
            $sql = "INSERT INTO disputes (order_id, user_id, reason, description, status)
                    VALUES (?, ?, ?, ?, 'open')";
            $stmt = $conn->prepare($sql);
            $stmt->bind_param("iiss", $order_id, $user_id, $reason, $description);

            if ($stmt->execute()) {
                $update = $conn->prepare("UPDATE orders SET order_status = 'disputed' WHERE order_id = ?");
                $update->bind_param("i", $order_id);
                $update->execute();

                $message = "Your dispute has been submitted successfully.";
            } else {
                $error = "Error submitting dispute. Please try again.";
            }
        }
    }
}

$orders_sql = "SELECT orders.order_id, listings.title
               FROM orders
               INNER JOIN listings ON orders.listing_id = listings.listing_id
               WHERE orders.buyer_id = ? OR orders.seller_id = ?
               ORDER BY orders.created_at DESC";
$order_stmt = $conn->prepare($orders_sql);
$order_stmt->bind_param("ii", $user_id, $user_id);
$order_stmt->execute();
$orders = $order_stmt->get_result();
?>

<h2>Report a Dispute</h2>
<p>Use this page to report a problem with a GreenTrade order.</p>

<?php if ($message): ?>
    <div class="alert alert-success"><?php echo htmlspecialchars($message); ?></div>
<?php endif; ?>

<?php if ($error): ?>
    <div class="alert alert-danger"><?php echo htmlspecialchars($error); ?></div>
<?php endif; ?>

<form method="POST" class="card card-body shadow-sm">
    <label class="form-label">Select Order</label>
    <select name="order_id" class="form-control mb-3" required>
        <option value="">Choose an order</option>
        <?php while ($order = $orders->fetch_assoc()): ?>
            <option value="<?php echo (int)$order['order_id']; ?>" <?php echo ($selected_order_id === (int)$order['order_id']) ? 'selected' : ''; ?>>
                Order #<?php echo (int)$order['order_id']; ?> - <?php echo htmlspecialchars($order['title']); ?>
            </option>
        <?php endwhile; ?>
    </select>

    <label class="form-label">Reason</label>
    <select name="reason" class="form-control mb-3" required>
        <option value="">Choose a reason</option>
        <option value="Item not received">Item not received</option>
        <option value="Wrong item received">Wrong item received</option>
        <option value="Item damaged">Item damaged</option>
        <option value="Fake payment">Fake payment</option>
        <option value="Seller not responding">Seller not responding</option>
        <option value="Buyer not responding">Buyer not responding</option>
        <option value="Other">Other</option>
    </select>

    <label class="form-label">Description</label>
    <textarea name="description" class="form-control mb-3" rows="5" placeholder="Explain what happened..." required></textarea>

    <button type="submit" class="btn btn-success">Submit Dispute</button>
</form>

<?php include "includes/footer.php"; ?>
