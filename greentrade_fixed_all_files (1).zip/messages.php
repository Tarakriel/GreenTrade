<?php
error_reporting(E_ALL);
ini_set('display_errors', 1);
session_start();

require_once __DIR__ . "/includes/db.php";
$user_id = 1;
$message_status = "";

if ($_SERVER["REQUEST_METHOD"] === "POST") {
    $receiver_id = (int)$_POST['receiver_id'];
    $listing_id = !empty($_POST['listing_id']) ? (int)$_POST['listing_id'] : null;
    $message = trim($_POST['message']);

    $sql = "INSERT INTO messages (sender_id, receiver_id, listing_id, message)
            VALUES (?, ?, ?, ?)";

    $stmt = $conn->prepare($sql);

    if (!$stmt) {
        die("Prepare failed: " . $conn->error);
    }

    $stmt->bind_param("iiis", $user_id, $receiver_id, $listing_id, $message);

    if ($stmt->execute()) {
        $message_status = "<div class='success'>Message sent successfully.</div>";
    } else {
        $message_status = "<div class='error'>Error: " . $conn->error . "</div>";
    }
}

$sql = "SELECT messages.*, 
               sender.full_name AS sender_name,
               receiver.full_name AS receiver_name,
               listings.title
        FROM messages
        INNER JOIN users AS sender ON messages.sender_id = sender.user_id
        INNER JOIN users AS receiver ON messages.receiver_id = receiver.user_id
        LEFT JOIN listings ON messages.listing_id = listings.listing_id
        ORDER BY messages.sent_at DESC";

$messages = $conn->query($sql);

if (!$messages) {
    die("SQL error: " . $conn->error);
}

$users = $conn->query("SELECT user_id, full_name FROM users ORDER BY full_name ASC");
$listings = $conn->query("SELECT listing_id, title FROM listings ORDER BY title ASC");
?>

<!DOCTYPE html>
<html>
<head>
    <title>Messages - GreenTrade</title>
    <style>
        body {
            margin: 0;
            font-family: Arial, sans-serif;
            background: #f4f8f4;
        }

        .navbar {
            background: #198754;
            color: white;
            padding: 18px 40px;
        }

        .navbar a {
            color: white;
            text-decoration: none;
            margin-right: 18px;
            font-weight: bold;
        }

        .container {
            padding: 30px 40px;
        }

        .form-card, .message-card {
            background: white;
            padding: 20px;
            border-radius: 12px;
            margin-bottom: 20px;
            box-shadow: 0 3px 10px rgba(0,0,0,0.08);
        }

        h1, h2 {
            color: #198754;
        }

        input, textarea, select {
            width: 100%;
            padding: 12px;
            margin-bottom: 15px;
            border-radius: 8px;
            border: 1px solid #ccc;
        }

        button {
            background: #198754;
            color: white;
            border: none;
            padding: 12px 18px;
            border-radius: 8px;
            font-weight: bold;
        }

        .success {
            background: #d1e7dd;
            color: #0f5132;
            padding: 12px;
            border-radius: 8px;
            margin-bottom: 15px;
        }

        .error {
            background: #f8d7da;
            color: #842029;
            padding: 12px;
            border-radius: 8px;
            margin-bottom: 15px;
        }
    </style>
</head>
<body>

<div class="navbar">
    <a href="listing.php">Browse</a>
    <a href="create_listing.php">Sell Item</a>
    <a href="orders.php">Orders</a>
    <a href="messages.php">Messages</a>
</div>

<div class="container">
    <h1>Messages</h1>

    <div class="form-card">
        <h2>Send Message</h2>

        <?php echo $message_status; ?>

        <form method="POST">
            <select name="receiver_id" required>
                <option value="">Select receiver</option>
                <?php while ($userRow = $users->fetch_assoc()): ?>
                    <option value="<?php echo $userRow['user_id']; ?>">
                        <?php echo htmlspecialchars($userRow['full_name']); ?>
                    </option>
                <?php endwhile; ?>
            </select>

            <select name="listing_id">
                <option value="">Select listing optional</option>
                <?php while ($listingRow = $listings->fetch_assoc()): ?>
                    <option value="<?php echo $listingRow['listing_id']; ?>">
                        <?php echo htmlspecialchars($listingRow['title']); ?>
                    </option>
                <?php endwhile; ?>
            </select>

            <textarea name="message" rows="5" placeholder="Type your message" required></textarea>

            <button type="submit">Send Message</button>
        </form>
    </div>

    <h2>Message History</h2>

    <?php if ($messages->num_rows > 0): ?>
        <?php while ($row = $messages->fetch_assoc()): ?>
            <div class="message-card">
                <p><strong>From:</strong> <?php echo htmlspecialchars($row['sender_name']); ?></p>
                <p><strong>To:</strong> <?php echo htmlspecialchars($row['receiver_name']); ?></p>
                <p><strong>Listing:</strong> <?php echo htmlspecialchars($row['title'] ?? 'No listing linked'); ?></p>
                <p><?php echo htmlspecialchars($row['message']); ?></p>
                <small><?php echo htmlspecialchars($row['sent_at']); ?></small>
            </div>
        <?php endwhile; ?>
    <?php else: ?>
        <div class="message-card">
            <p>No messages found.</p>
        </div>
    <?php endif; ?>
</div>

</body>
</html>